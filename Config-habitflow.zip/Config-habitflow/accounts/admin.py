from django.contrib import admin
from django.contrib.auth.admin import UserAdmin  # importamos o UserAdmin padrão
from .models import CustomUser

admin.site.register(CustomUser, UserAdmin)  # registramos o nosso CustomUser usando o admin pronto do Django
