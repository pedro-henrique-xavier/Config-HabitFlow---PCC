from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser

# Formulário de criação de usuário (com senha, confirmação, imagem, etc.)
class CustomUserCreationForm(UserCreationForm):
    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'photo', 'password1', 'password2']

# Formulário para editar perfil (sem mudar senha)
class CustomUserChangeForm(forms.ModelForm):
    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'photo']
