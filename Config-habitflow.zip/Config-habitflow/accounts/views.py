from django.shortcuts import render, redirect
from django.contrib.auth import login  # para logar o usuário automaticamente após cadastro
from .forms import CustomUserCreationForm, CustomUserChangeForm
from django.contrib.auth.decorators import login_required  # protege páginas que exigem login

# Página de cadastro de novo usuário
def register(request):
    if request.method == 'POST':  # se o formulário foi enviado
        form = CustomUserCreationForm(request.POST, request.FILES)
        if form.is_valid():
            user = form.save()  # salva no banco
            login(request, user)  # loga o usuário automaticamente
            return redirect('profile')  # redireciona para perfil
    else:
        form = CustomUserCreationForm()  # formulário vazio para GET
    return render(request, 'accounts/register.html', {'form': form})  # renderiza o HTML com o formulário

# Página de perfil do usuário logado
@login_required  # só acessa se estiver logado
def profile(request):
    if request.method == 'POST':
        form = CustomUserChangeForm(request.POST, request.FILES, instance=request.user)  # edita os dados do usuário atual
        if form.is_valid():
            form.save()
            return redirect('profile')
    else:
        form = CustomUserChangeForm(instance=request.user)
    return render(request, 'accounts/profile.html', {'form': form})
