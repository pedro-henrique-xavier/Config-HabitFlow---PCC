from django.contrib import admin
from .models import Battle, BattleParticipant, ActivityReport

@admin.register(Battle)
class BattleAdmin(admin.ModelAdmin):
    list_display = ('name', 'creator', 'start_date', 'end_date', 'status', 'created_at')
    list_filter = ('status', 'start_date', 'end_date')
    search_fields = ('name', 'creator__username')

@admin.register(BattleParticipant)
class BattleParticipantAdmin(admin.ModelAdmin):
    list_display = ('battle', 'user', 'status', 'joined_at')
    list_filter = ('status', 'joined_at')
    search_fields = ('battle__name', 'user__username')

@admin.register(ActivityReport)
class ActivityReportAdmin(admin.ModelAdmin):
    list_display = ('battle', 'reported_user', 'reporter', 'activity_type', 'resolved', 'created_at')
    list_filter = ('activity_type', 'resolved', 'created_at')
    search_fields = ('reported_user__username', 'reporter__username', 'battle__name')

