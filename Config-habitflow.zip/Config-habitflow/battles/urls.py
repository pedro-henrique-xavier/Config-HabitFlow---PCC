from django.urls import path
from . import views

app_name = 'battles'

urlpatterns = [
    path('', views.battle_list, name='list'),
    path('create/', views.battle_create, name='create'),
    path('join/', views.battle_join, name='join'),
    path('<int:battle_id>/', views.battle_detail, name='detail'),
    path('<int:battle_id>/edit/', views.battle_edit, name='edit'),
    path('<int:battle_id>/delete/', views.battle_delete, name='delete'),
    path('invite/<int:participant_id>/<str:action>/', views.battle_invite_response, name='invite_response'),
    path('<int:battle_id>/report/<int:user_id>/', views.activity_report, name='activity_report'),
]

