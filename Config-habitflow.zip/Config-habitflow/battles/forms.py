from django import forms
from django.contrib.auth import get_user_model
from .models import Battle, ActivityReport

User = get_user_model()

class BattleForm(forms.ModelForm):
    class Meta:
        model = Battle
        fields = ['name', 'start_date', 'end_date', 'count_tasks', 'count_habits', 'count_routines']
        widgets = {
            'start_date': forms.DateInput(attrs={'type': 'date'}),
            'end_date': forms.DateInput(attrs={'type': 'date'}),
        }
        labels = {
            'name': 'Nome da Batalha',
            'start_date': 'Data de Início',
            'end_date': 'Data de Fim',
            'count_tasks': 'Contar Tarefas',
            'count_habits': 'Contar Hábitos',
            'count_routines': 'Contar Rotinas',
        }

class JoinBattleForm(forms.Form):
    battle_code = forms.CharField(
        max_length=8,
        label="Código da Batalha",
        widget=forms.TextInput(attrs={
            'placeholder': 'Digite o código de 8 caracteres',
            'style': 'text-transform: uppercase;'
        })
    )
    
    def clean_battle_code(self):
        code = self.cleaned_data['battle_code'].upper()
        try:
            battle = Battle.objects.get(battle_code=code)
            if battle.is_finished:
                raise forms.ValidationError("Esta batalha já foi finalizada.")
            return code
        except Battle.DoesNotExist:
            raise forms.ValidationError("Código de batalha inválido.")

class ActivityReportForm(forms.ModelForm):
    class Meta:
        model = ActivityReport
        fields = ['report_reason']
        widgets = {
            'report_reason': forms.Textarea(attrs={'rows': 3}),
        }
        labels = {
            'report_reason': 'Motivo do Report',
        }

