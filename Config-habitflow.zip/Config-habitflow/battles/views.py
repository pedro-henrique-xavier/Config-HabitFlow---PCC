from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, Sum
from django.utils import timezone
from django.http import JsonResponse
from .models import Battle, BattleParticipant, ActivityReport
from .forms import BattleForm, ActivityReportForm, JoinBattleForm
from accounts.models import CustomUser
from tasks.models import Task
from habits.models import Habit, HabitCompletion
from routine.models import WeeklyRoutineItem

@login_required
def battle_list(request):
    """Lista todas as batalhas do usuário"""
    # Batalhas onde o usuário é participante ou criador
    user_battles = Battle.objects.filter(
        Q(creator=request.user) | Q(participants__user=request.user)
    ).distinct().order_by('-created_at')
    
    # Convites pendentes
    pending_invites = BattleParticipant.objects.filter(
        user=request.user,
        status='invited'
    )
    
    context = {
        'battles': user_battles,
        'pending_invites': pending_invites,
    }
    return render(request, 'battles/battle_list.html', context)

@login_required
def battle_create(request):
    """Criar uma nova batalha"""
    if request.method == 'POST':
        form = BattleForm(request.POST)
        if form.is_valid():
            battle = form.save(commit=False)
            battle.creator = request.user
            battle.save()
            
            # Adiciona o criador como participante aceito
            BattleParticipant.objects.create(
                battle=battle,
                user=request.user,
                status='accepted'
            )
            
            messages.success(request, f'Batalha criada com sucesso! Código: {battle.battle_code}')
            return redirect('battles:detail', battle_id=battle.id)
    else:
        form = BattleForm()
    
    return render(request, 'battles/battle_create.html', {'form': form})

@login_required
def battle_join(request):
    """Participar de uma batalha usando código"""
    if request.method == 'POST':
        form = JoinBattleForm(request.POST)
        if form.is_valid():
            code = form.cleaned_data['battle_code']
            battle = Battle.objects.get(battle_code=code)
            
            # Verifica se já é participante
            participant, created = BattleParticipant.objects.get_or_create(
                battle=battle,
                user=request.user,
                defaults={'status': 'accepted'}
            )
            
            if created:
                messages.success(request, f'Você entrou na batalha "{battle.name or "Batalha"}"!')
            else:
                messages.info(request, 'Você já participa desta batalha.')
            
            return redirect('battles:detail', battle_id=battle.id)
    else:
        form = JoinBattleForm()
    
    return render(request, 'battles/battle_join.html', {'form': form})

@login_required
def battle_detail(request, battle_id):
    """Detalhe da batalha com ranking"""
    battle = get_object_or_404(Battle, id=battle_id)
    
    # Verifica se o usuário é participante
    is_participant = BattleParticipant.objects.filter(
        battle=battle,
        user=request.user,
        status='accepted'
    ).exists() or battle.creator == request.user
    
    if not is_participant:
        messages.error(request, 'Você não tem acesso a esta batalha.')
        return redirect('battles:list')
    
    # Calcula o ranking dos participantes baseado nas atividades durante a batalha
    participants = BattleParticipant.objects.filter(
        battle=battle,
        status='accepted'
    ).select_related('user')
    
    ranking = []
    for participant in participants:
        user_points = calculate_battle_points(participant.user, battle)
        ranking.append({
            'user': participant.user,
            'points': user_points,
        })
    
    # Ordena por pontos (maior primeiro)
    ranking.sort(key=lambda x: x['points'], reverse=True)
    
    context = {
        'battle': battle,
        'ranking': ranking,
        'is_creator': battle.creator == request.user,
    }
    return render(request, 'battles/battle_detail.html', context)

@login_required
def battle_edit(request, battle_id):
    """Editar batalha (apenas criador)"""
    battle = get_object_or_404(Battle, id=battle_id, creator=request.user)
    
    if request.method == 'POST':
        form = BattleForm(request.POST, instance=battle)
        if form.is_valid():
            form.save()
            messages.success(request, 'Batalha atualizada com sucesso!')
            return redirect('battles:detail', battle_id=battle.id)
    else:
        form = BattleForm(instance=battle)
    
    return render(request, 'battles/battle_edit.html', {'form': form, 'battle': battle})

@login_required
def battle_delete(request, battle_id):
    """Excluir batalha (apenas criador)"""
    battle = get_object_or_404(Battle, id=battle_id, creator=request.user)
    
    if request.method == 'POST':
        battle.delete()
        messages.success(request, 'Batalha excluída com sucesso!')
        return redirect('battles:list')
    
    return render(request, 'battles/battle_delete.html', {'battle': battle})

@login_required
def battle_invite_response(request, participant_id, action):
    """Aceitar ou recusar convite para batalha"""
    participant = get_object_or_404(BattleParticipant, id=participant_id, user=request.user)
    
    if action == 'accept':
        participant.status = 'accepted'
        participant.save()
        messages.success(request, f'Você aceitou o convite para a batalha "{participant.battle.name or "Batalha"}"!')
    elif action == 'decline':
        participant.status = 'declined'
        participant.save()
        messages.info(request, f'Você recusou o convite para a batalha "{participant.battle.name or "Batalha"}".')
    
    return redirect('battles:list')

@login_required
def activity_report(request, battle_id, user_id):
    """Reportar atividade suspeita de um usuário"""
    battle = get_object_or_404(Battle, id=battle_id)
    reported_user = get_object_or_404(CustomUser, id=user_id)
    
    # Verifica se o usuário é participante da batalha
    is_participant = BattleParticipant.objects.filter(
        battle=battle,
        user=request.user,
        status='accepted'
    ).exists()
    
    if not is_participant:
        messages.error(request, 'Você não tem permissão para reportar nesta batalha.')
        return redirect('battles:detail', battle_id=battle.id)
    
    # Busca atividades do usuário reportado durante a batalha
    user_activities = get_user_activities_in_battle(reported_user, battle)
    
    if request.method == 'POST':
        form = ActivityReportForm(request.POST)
        activity_type = request.POST.get('activity_type')
        activity_id = request.POST.get('activity_id')
        
        if form.is_valid():
            report = form.save(commit=False)
            report.battle = battle
            report.reported_user = reported_user
            report.reporter = request.user
            report.activity_type = activity_type
            report.activity_id = activity_id
            
            # Busca a descrição da atividade
            activity_description = get_activity_description(activity_type, activity_id)
            report.activity_description = activity_description
            
            report.save()
            
            messages.success(request, 'Report enviado com sucesso!')
            return redirect('battles:detail', battle_id=battle.id)
    else:
        form = ActivityReportForm()
    
    context = {
        'form': form,
        'battle': battle,
        'reported_user': reported_user,
        'user_activities': user_activities,
    }
    return render(request, 'battles/activity_report.html', context)

def calculate_battle_points(user, battle):
    """Calcula os pontos do usuário durante o período da batalha"""
    points = 0
    
    # Tarefas concluídas
    if battle.count_tasks:
        tasks = Task.objects.filter(
            user=user,
            completed=True,
            deadline__gte=battle.start_date,
            deadline__lte=battle.end_date
        )
        points += tasks.count() * 1  # 1 ponto por tarefa
    
    # Hábitos concluídos
    if battle.count_habits:
        habit_completions = HabitCompletion.objects.filter(
            habit__user=user,
            date__gte=battle.start_date,
            date__lte=battle.end_date
        )
        # Agrupa por hábito e semana para calcular hábitos semanais completos
        # Simplificado: 7 pontos por hábito semanal completo
        points += habit_completions.count() * 7
    
    # Rotinas concluídas
    if battle.count_routines:
        routine_completions = WeeklyRoutineItem.objects.filter(
            user=user,
            is_completed=True,
            # Adicionar filtro de data quando disponível
        )
        points += routine_completions.count() * 5  # 5 pontos por rotina completa
    
    return points

def get_user_activities_in_battle(user, battle):
    """Busca todas as atividades do usuário durante a batalha"""
    activities = []
    
    # Tarefas
    if battle.count_tasks:
        tasks = Task.objects.filter(
            user=user,
            completed=True,
            deadline__gte=battle.start_date,
            deadline__lte=battle.end_date
        )
        for task in tasks:
            activities.append({
                'type': 'task',
                'id': task.id,
                'title': task.title,
                'date': task.deadline,
                'points': 1
            })
    
    # Hábitos
    if battle.count_habits:
        habit_completions = HabitCompletion.objects.filter(
            habit__user=user,
            date__gte=battle.start_date,
            date__lte=battle.end_date
        ).select_related('habit')
        for completion in habit_completions:
            activities.append({
                'type': 'habit',
                'id': completion.id,
                'title': completion.habit.title,
                'date': completion.date,
                'points': 7
            })
    
    # Rotinas
    if battle.count_routines:
        routine_completions = WeeklyRoutineItem.objects.filter(
            user=user,
            is_completed=True
        )
        for routine in routine_completions:
            activities.append({
                'type': 'routine',
                'id': routine.id,
                'title': routine.title,
                'date': timezone.now().date(),  # Simplificado
                'points': 5
            })
    
    return sorted(activities, key=lambda x: x['date'], reverse=True)

def get_activity_description(activity_type, activity_id):
    """Busca a descrição de uma atividade específica"""
    try:
        if activity_type == 'task':
            task = Task.objects.get(id=activity_id)
            return f"Tarefa: {task.title}"
        elif activity_type == 'habit':
            completion = HabitCompletion.objects.get(id=activity_id)
            return f"Hábito: {completion.habit.title} em {completion.date}"
        elif activity_type == 'routine':
            routine = WeeklyRoutineItem.objects.get(id=activity_id)
            return f"Rotina: {routine.title}"
    except:
        return "Atividade não encontrada"
    
    return "Atividade desconhecida"

