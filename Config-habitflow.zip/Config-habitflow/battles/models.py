from django.db import models
from django.conf import settings
from django.utils import timezone
import string
import random

class Battle(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pendente'),
        ('active', 'Ativa'),
        ('finished', 'Finalizada'),
    ]
    
    name = models.CharField(max_length=100, blank=True, null=True)
    creator = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='created_battles')
    start_date = models.DateField()
    end_date = models.DateField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    
    # Novo campo para código de participação
    battle_code = models.CharField(max_length=8, unique=True, blank=True)
    
    # Critérios de pontuação
    count_tasks = models.BooleanField(default=True, verbose_name="Contar Tarefas")
    count_habits = models.BooleanField(default=True, verbose_name="Contar Hábitos")
    count_routines = models.BooleanField(default=True, verbose_name="Contar Rotinas")
    
    def save(self, *args, **kwargs):
        if not self.battle_code:
            self.battle_code = self.generate_battle_code()
        super().save(*args, **kwargs)
    
    def generate_battle_code(self):
        """Gera um código único de 8 caracteres para a batalha"""
        while True:
            code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
            if not Battle.objects.filter(battle_code=code).exists():
                return code
    
    def __str__(self):
        return f"{self.name or 'Batalha'} - {self.creator.username}"
    
    @property
    def is_active(self):
        today = timezone.now().date()
        return self.start_date <= today <= self.end_date and self.status == 'active'
    
    @property
    def is_finished(self):
        today = timezone.now().date()
        return today > self.end_date or self.status == 'finished'

class BattleParticipant(models.Model):
    STATUS_CHOICES = [
        ('invited', 'Convidado'),
        ('accepted', 'Aceito'),
        ('declined', 'Recusado'),
    ]
    
    battle = models.ForeignKey(Battle, on_delete=models.CASCADE, related_name='participants')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='invited')
    joined_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ('battle', 'user')
    
    def __str__(self):
        return f"{self.user.username} - {self.battle.name or 'Batalha'} ({self.status})"

class ActivityReport(models.Model):
    battle = models.ForeignKey(Battle, on_delete=models.CASCADE, related_name='reports')
    reported_user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='reported_activities')
    reporter = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='activity_reports')
    activity_type = models.CharField(max_length=20)  # 'task', 'habit', 'routine'
    activity_id = models.IntegerField()  # ID da atividade específica
    activity_description = models.TextField()
    report_reason = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    resolved = models.BooleanField(default=False)
    
    def __str__(self):
        return f"Report: {self.reported_user.username} - {self.activity_type}"

