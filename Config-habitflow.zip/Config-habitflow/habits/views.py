# habits/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Habit, HabitCompletion, WeeklyPointsAwarded
from .forms import HabitForm
from django.utils import timezone
from datetime import date, timedelta, datetime


@login_required
def habit_create(request):
    if request.method == 'POST':
        form = HabitForm(request.POST)
        if form.is_valid():
            habit = form.save(commit=False)
            habit.user = request.user
            habit.save()
            return redirect('calendar')
    else:
        form = HabitForm()
    return render(request, 'habits/habit_form.html', {'form': form})

@login_required
def habit_edit(request, habit_id):
    habit = get_object_or_404(Habit, id=habit_id, user=request.user)
    if request.method == 'POST':
        form = HabitForm(request.POST, instance=habit)
        if form.is_valid():
            form.save()
            return redirect('calendar')
    else:
        form = HabitForm(instance=habit)
    return render(request, 'habits/habit_form.html', {'form': form})

@login_required
def habit_delete(request, habit_id):
    habit = get_object_or_404(Habit, id=habit_id, user=request.user)
    habit.delete()
    return redirect('calendar')

@login_required
def habit_toggle_done(request, habit_id):
    habit = get_object_or_404(Habit, id=habit_id, user=request.user)
    today = date.today()
    completion, created = HabitCompletion.objects.get_or_create(habit=habit, date=today)

    if completion.completed_times >= habit.repetitions_per_day:
        # desmarcar como feito
        completion.completed_times = 0
    else:
        completion.completed_times += 1

    completion.save()
    return redirect('calendar')



from django.contrib.auth.decorators import login_required
from .models import Habit, HabitCompletion
from datetime import date

from datetime import timedelta, date

@login_required
def habit_list(request):
    habits = Habit.objects.filter(user=request.user)
    completions = HabitCompletion.objects.filter(habit__in=habits)

    from collections import defaultdict
    completion_dict = defaultdict(dict)
    for c in completions:
        completion_dict[c.habit.id][str(c.date)] = c

    # ✅ Geração da semana completa (segunda a domingo)
    today = timezone.now().date()
    start_of_week = today - timedelta(days=today.weekday())
    week_dates = [start_of_week + timedelta(days=i) for i in range(7)]

    return render(request, 'habits/habit_list.html', {
        'habits': habits,
        'completion_dict': dict(completion_dict),
        'week_dates': week_dates,
    })


from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.utils.dateparse import parse_date
from .models import Habit, HabitCompletion

@require_POST
@login_required
def habit_toggle_day(request, habit_id):
    habit = get_object_or_404(Habit, id=habit_id, user=request.user)
    date_str = request.POST.get("date")

    try:
        target_date = datetime.strptime(date_str, "%Y-%m-%d").date()
    except ValueError:
        return redirect(request.META.get('HTTP_REFERER', 'calendar'))

    completion, created = HabitCompletion.objects.get_or_create(
        habit=habit,
        date=target_date
    )

    # Verifica o estado atual antes de alternar
    was_completed_for_day = completion.completed_times >= 1

    # ⚡ Marca como feito ou não — 0 ou 1
    if was_completed_for_day:
        completion.completed_times = 0
    else:
        completion.completed_times = 1

    completion.save()

    # Lógica para pontos de hábitos semanais
    # Mapeamento de dias da semana de string para inteiro (0=segunda, 6=domingo)
    day_name_to_int = {
        'mon': 0, 'tue': 1, 'wed': 2, 'thu': 3, 'fri': 4, 'sat': 5, 'sun': 6
    }

    # Converte os dias do hábito para inteiros
    habit_days_int = [day_name_to_int[d] for d in habit.days]

    start_of_week = target_date - timedelta(days=target_date.weekday())

    # Se o hábito foi marcado como completo para o dia (e não estava antes)
    if completion.completed_times == 1 and not was_completed_for_day:
        # Conta quantos dias na semana o hábito foi completado (pelo menos 1 repetição)
        completed_days_in_week = HabitCompletion.objects.filter(
            habit=habit,
            date__range=[start_of_week, start_of_week + timedelta(days=6)],
            completed_times__gte=1 # Pelo menos uma repetição para contar como dia completo
        ).count()

        # Se o número de dias com o hábito completo na semana for igual ao número de dias que o hábito deve ser feito
        if completed_days_in_week == len(habit_days_int):
            # Verifica se os pontos já foram concedidos para esta semana e hábito
            weekly_award, created_award = WeeklyPointsAwarded.objects.get_or_create(
                user=request.user,
                habit=habit,
                week_start_date=start_of_week
            )
            if created_award: # Se o registro foi criado agora, significa que os pontos não foram dados ainda
                request.user.points += 7  # Adiciona 7 pontos por hábito semanal completo
                request.user.save()
                weekly_award.awarded = True
                weekly_award.save()

    elif not completion.completed_times == 1 and was_completed_for_day: # Se o hábito foi desmarcado para o dia
        # Verifica se a conclusão semanal foi desfeita e se os pontos precisam ser removidos
        completed_days_in_week_after_unmark = HabitCompletion.objects.filter(
            habit=habit,
            date__range=[start_of_week, start_of_week + timedelta(days=6)],
            completed_times__gte=1
        ).count()

        # Se antes estava completo semanalmente e agora não está mais
        if completed_days_in_week_after_unmark < len(habit_days_int): # Se o número de dias completos caiu abaixo do necessário
            weekly_award = WeeklyPointsAwarded.objects.filter(
                user=request.user,
                habit=habit,
                week_start_date=start_of_week,
                awarded=True
            ).first()
            if weekly_award: # Se os pontos foram concedidos para esta semana e hábito
                request.user.points -= 7  # Remove 7 pontos
                request.user.save()
                weekly_award.awarded = False
                weekly_award.save()

    return redirect(request.META.get('HTTP_REFERER', 'calendar'))

