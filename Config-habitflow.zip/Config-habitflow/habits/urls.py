# habits/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.habit_list, name='habit_list'),
    path('create/', views.habit_create, name='habit_create'),
    path('edit/<int:habit_id>/', views.habit_edit, name='habit_edit'),
    path('delete/<int:habit_id>/', views.habit_delete, name='habit_delete'),
    path('toggle/<int:habit_id>/', views.habit_toggle_done, name='habit_toggle_done'),
    path('toggle_day/<int:habit_id>/', views.habit_toggle_day, name='habit_toggle_day'),
    

]
