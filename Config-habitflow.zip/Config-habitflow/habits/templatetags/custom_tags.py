from django import template

register = template.Library()

@register.filter
def get_item(dictionary, key):
    return dictionary.get(key) if dictionary else None

import logging
logger = logging.getLogger(__name__)

@register.filter
def has_day(habit, date_obj):
    day_key = date_obj.strftime("%a").lower()[:3]
   
    return day_key in habit.days


@register.filter
def day_name_abbr(code):
    names = {
        'mon': 'Seg', 'tue': 'Ter', 'wed': 'Qua',
        'thu': 'Qui', 'fri': 'Sex', 'sat': 'Sáb', 'sun': 'Dom'
    }
    return names.get(code.lower(), code.upper())
    
@register.filter
def get_item(dictionary, key):
    return dictionary.get(key) if dictionary else None

