# habits/models.py
from django.db import models
from django.contrib.auth import get_user_model
from django.utils import timezone

User = get_user_model()

DAYS_OF_WEEK = [
    ('mon', 'Segunda'),
    ('tue', 'Terça'),
    ('wed', 'Quarta'),
    ('thu', 'Quinta'),
    ('fri', 'Sexta'),
    ('sat', 'Sábado'),
    ('sun', 'Domingo'),
]

class Habit(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='habits')
    title = models.CharField(max_length=100)
    days = models.JSONField()  # ["mon", "wed"]

    def __str__(self):
        return self.title

class HabitCompletion(models.Model):
    habit = models.ForeignKey(Habit, on_delete=models.CASCADE)
    date = models.DateField()
    completed_times = models.PositiveIntegerField(default=0)

    class Meta:
        unique_together = ('habit', 'date')

class WeeklyPointsAwarded(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    habit = models.ForeignKey(Habit, on_delete=models.CASCADE)
    week_start_date = models.DateField()
    awarded = models.BooleanField(default=False)

    class Meta:
        unique_together = ("user", "habit", "week_start_date")
        verbose_name = "Weekly Points Awarded"
        verbose_name_plural = "Weekly Points Awarded"

    def __str__(self):
        return f"{self.user.username} - {self.habit.title} - Week of {self.week_start_date} - Awarded: {self.awarded}"

