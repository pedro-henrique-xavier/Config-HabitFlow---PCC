from django import forms
from .models import Habit

DAYS_OF_WEEK_CHOICES = [
    ('mon', 'Segunda'),
    ('tue', 'Terça'),
    ('wed', 'Quarta'),
    ('thu', 'Quinta'),
    ('fri', 'Sexta'),
    ('sat', 'Sábado'),
    ('sun', 'Domingo'),
]

class HabitForm(forms.ModelForm):
    days = forms.MultipleChoiceField(
        choices=DAYS_OF_WEEK_CHOICES,
        widget=forms.CheckboxSelectMultiple,
    )

    class Meta:
        model = Habit
        fields = ['title', 'days']

    def clean_times(self):
        data = self.cleaned_data['times']
        # converte string para lista de horários, limpando espaços
        times_list = [t.strip() for t in data.split(',') if t.strip()]
        return times_list
