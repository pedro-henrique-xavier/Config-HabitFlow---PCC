from django.shortcuts import render
from tasks.models import Task
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from habits.models import Habit, HabitCompletion
from datetime import timedelta
from django.utils import timezone
from routine.models import WeeklyRoutineItem
import json
from django.views.decorators.http import require_POST

@login_required
def get_tasks(request):
    tasks = Task.objects.filter(user=request.user)
    events = []

    for task in tasks:
        events.append({
            'id': task.id,
            'title': task.title,
            'start': task.deadline.isoformat(),
            'end': task.deadline.isoformat(),
            'url': f"/tasks/edit/{task.id}/",
            'color': '#198754' if task.completed else '#0d6efd',
        })

    return JsonResponse(events, safe=False)

@require_POST
@login_required
def update_task_date(request, task_id):
    try:
        data = json.loads(request.body)
        new_date = data.get('new_date')
        task = Task.objects.get(id=task_id, user=request.user)
        task.deadline = new_date
        task.save()
        return JsonResponse({'status': 'ok'})
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=400)


@login_required
def calendar_view(request):
    user = request.user
    today = timezone.now().date()

    # Mapeamento dos dias da semana
    weekday_map = {
        0: 'segunda',
        1: 'terca',
        2: 'quarta',
        3: 'quinta',
        4: 'sexta',
        5: 'sabado',
        6: 'domingo'
    }
    current_day_key = weekday_map[today.weekday()]

    # Rotina do dia atual
    routine_by_day = {
        current_day_key: WeeklyRoutineItem.objects.filter(
            user=user,
            day_of_week=current_day_key
        ).order_by('time')
    }

    # Semana de segunda a domingo
    start_of_week = today - timedelta(days=today.weekday())
    week_dates = [start_of_week + timedelta(days=i) for i in range(7)]

    # Tarefas
    tasks = Task.objects.filter(user=user)
    tasks_by_day = {}
    for task in tasks:
        if task.deadline:
            day = task.deadline.strftime('%Y-%m-%d')
            if day not in tasks_by_day:
                tasks_by_day[day] = []
            tasks_by_day[day].append(task)

    # Hábitos
    habits = Habit.objects.filter(user=user)
    completions = HabitCompletion.objects.filter(
        habit__in=habits,
        date__gte=start_of_week,
        date__lte=start_of_week + timedelta(days=6)
    )

    # Dicionário de status de conclusão — agora SEM repetições
    habit_completions = {}
    for habit in habits:
        habit_completions[habit.id] = {}
        for completion in completions.filter(habit=habit):
            habit_completions[habit.id][str(completion.date)] = (
                completion.completed_times > 0  # Só verifica se > 0
            )

    return render(request, 'calendar_app/calendar.html', {
        'tasks': tasks,
        'habits': habits,
        'week_dates': week_dates,
        'habit_completions': habit_completions,
        'tasks_by_day': tasks_by_day,
        'today': today,
        'routine_by_day': routine_by_day,
        'current_day_key': current_day_key,
    })
