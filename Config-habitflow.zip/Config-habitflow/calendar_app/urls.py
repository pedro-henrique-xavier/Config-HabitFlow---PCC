from django.urls import path
from . import views

urlpatterns = [
    path('', views.calendar_view, name='calendar'),
    path('events/', views.get_tasks, name='calendar_events'),  # retorna as tarefas em JSON
    path('update-date/<int:task_id>/', views.update_task_date, name='update_task_date'),
    path('update-date/<int:task_id>/', views.update_task_date, name='update_task_date'),

]
