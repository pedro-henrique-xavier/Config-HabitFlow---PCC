from django.db import models
from accounts.models import CustomUser

class Notification(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    message = models.CharField(max_length=255)
    scheduled_time = models.DateTimeField()
    sent = models.BooleanField(default=False)
