from django.shortcuts import render, redirect, get_object_or_404
from .models import Task
from .forms import TaskForm
from django.contrib.auth.decorators import login_required
from django.utils import timezone


@login_required
def task_list(request):
    tasks = Task.objects.filter(user=request.user).order_by("-deadline")
    return render(request, "tasks/task_list.html", {"tasks": tasks})


@login_required
def task_create(request):
    if request.method == "POST":
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)
            task.user = request.user
            task.save()

            # Redireciona para onde veio
            next_url = request.GET.get("next", "task_list")
            return redirect(next_url)
    else:
        form = TaskForm()

    return render(request, "tasks/task_form.html", {"form": form})


@login_required
def task_edit(request, task_id):
    task = get_object_or_404(Task, pk=task_id, user=request.user)
    if request.method == "POST":
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            return redirect("task_list")
    else:
        form = TaskForm(instance=task)
    return render(request, "tasks/task_form.html", {"form": form})


@login_required
def task_delete(request, task_id):
    task = get_object_or_404(Task, pk=task_id, user=request.user)
    task.delete()
    return redirect("task_list")


from django.views.decorators.http import require_POST


@require_POST
@login_required
def task_toggle_complete(request, task_id):
    task = get_object_or_404(Task, id=task_id, user=request.user)
    
    # Verifica o estado atual antes de alternar
    was_completed = task.completed
    
    task.completed = not task.completed
    task.save()

    # Se a tarefa foi marcada como concluída (e não estava antes)
    if task.completed and not was_completed:
        request.user.points += 1  # Adiciona 1 ponto por tarefa diária
        request.user.save()
    # Se a tarefa foi desmarcada como concluída
    elif not task.completed and was_completed:
        request.user.points -= 1  # Remove 1 ponto se a tarefa for desmarcada
        request.user.save()

    return redirect(request.META.get("HTTP_REFERER", "task_list"))


from django.views.decorators.http import require_POST
from django.shortcuts import redirect, get_object_or_404
from django.contrib.auth.decorators import login_required


@require_POST
@login_required
def task_complete(request, task_id):
    task = get_object_or_404(Task, id=task_id, user=request.user)
    
    if not task.completed: # Só adiciona pontos se a tarefa não estava completa
        task.completed = True
        task.save()
        request.user.points += 1  # Adiciona 1 ponto por tarefa diária
        request.user.save()

    return redirect("calendar")  # ou "task_list", se preferir


from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from collections import defaultdict, OrderedDict
from datetime import timedelta
from .models import Task
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from .models import Task
from collections import defaultdict, OrderedDict
from datetime import timedelta


@login_required
def task_list(request):
    tasks = Task.objects.filter(user=request.user).order_by("-deadline")

    # Agrupa tarefas por semana (segunda a domingo)
    weeks_dict = defaultdict(lambda: defaultdict(list))

    for task in tasks:
        if not task.deadline:
            continue  # ignora tarefas sem deadline
        start_of_week = task.deadline.date() - timedelta(days=task.deadline.weekday())
        week_key = start_of_week
        day_key = task.deadline.strftime("%a (%d/%m)")

        weeks_dict[week_key][day_key].append(task)

    # Ordena as semanas mais recentes primeiro
    sorted_weeks = sorted(weeks_dict.items(), reverse=True)

    # Transforma em estrutura compatível com o template
    weeks = []
    for week_start, days in sorted_weeks:
        week_data = {
            "start": week_start,
            "end": week_start + timedelta(days=6),
            "days": OrderedDict(
                sorted(days.items(), key=lambda x: x[0], reverse=True)
            ),  # dias mais recentes no topo
        }
        weeks.append(week_data)

    return render(request, "tasks/task_list.html", {"weeks": weeks})


