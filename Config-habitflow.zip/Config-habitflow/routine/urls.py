from django.urls import path
from . import views

urlpatterns = [
    path('', views.weekly_routine_view, name='weekly_routine'),
    path('create/', views.create_activity, name='create_activity'),
    path('edit/<int:pk>/', views.edit_activity, name='edit_activity'),
    path('delete/<int:pk>/', views.delete_activity, name='delete_activity'),
    path('toggle/<int:pk>/', views.toggle_activity_completion, name='toggle_activity_completion'),  # ✅ NOVO
]
