from django.shortcuts import render, redirect, get_object_or_404
from .models import WeeklyRoutineItem, DIAS_SEMANA
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.template.defaulttags import register
from datetime import date
from django.views.decorators.http import require_POST

@register.filter
def get_item(dictionary, key):
    return dictionary.get(key)

@login_required
def weekly_routine_view(request):
    routine_by_day = {
        dia[0]: WeeklyRoutineItem.objects.filter(
            user=request.user, 
            day_of_week=dia[0]
        ).order_by("time")
        for dia in DIAS_SEMANA
    }

    context = {
        "routine_by_day": routine_by_day,
        "dias_semana": DIAS_SEMANA,
    }
    return render(request, "routine/weekly_routine.html", context)

@login_required
def create_activity(request):
    if request.method == "POST":
        days = request.POST.getlist("days")
        title = request.POST.get("title")
        time = request.POST.get("time")
        description = request.POST.get("description", "")
        
        if days and title and time:
            created_items = []
            for day in days:
                item = WeeklyRoutineItem.objects.create(
                    user=request.user,
                    day_of_week=day,
                    title=title,
                    time=time,
                    description=description
                )
                created_items.append(item)
            
            if request.headers.get("X-Requested-With") == "XMLHttpRequest":
                data = {}
                for day in days:
                    routine_items = WeeklyRoutineItem.objects.filter(
                        user=request.user,
                        day_of_week=day
                    ).order_by("time")
                    data[day] = [{
                        "id": item.id,
                        "time": item.time.strftime("%H:%M"),
                        "title": item.title,
                        "description": item.description
                    } for item in routine_items]
                return JsonResponse({"success": True, "activities": data})
            
    return redirect("weekly_routine")

@login_required
def edit_activity(request, pk):
    activity = get_object_or_404(WeeklyRoutineItem, pk=pk, user=request.user)
    
    if request.method == "POST":
        activity.title = request.POST.get("title")
        activity.time = request.POST.get("time")
        activity.description = request.POST.get("description", "")
        activity.save()
        return redirect("weekly_routine")
    
    return render(request, "routine/edit_activity.html", {
        "activity": activity,
        "day_name": dict(DIAS_SEMANA).get(activity.day_of_week)
    })

@login_required
def delete_activity(request, pk):
    activity = get_object_or_404(WeeklyRoutineItem, pk=pk, user=request.user)
    day_of_week = activity.day_of_week
    
    if request.method == "POST":
        activity.delete()
        
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            routine_items = WeeklyRoutineItem.objects.filter(
                user=request.user,
                day_of_week=day_of_week
            ).order_by("time")
            data = [{
                "id": item.id,
                "time": item.time.strftime("%H:%M"),
                "title": item.title,
                "description": item.description
            } for item in routine_items]
            return JsonResponse({"success": True, "activities": data})
        
    return redirect("weekly_routine")

@require_POST
@login_required
def toggle_activity_completion(request, pk):
    activity = get_object_or_404(WeeklyRoutineItem, pk=pk, user=request.user)
    
    # Verifica o estado atual antes de alternar
    was_completed = activity.is_completed

    activity.is_completed = not activity.is_completed
    activity.save()

    # Mapeia o dia da semana de inteiro para string
    day_mapping = {
        0: 'segunda',
        1: 'terca',
        2: 'quarta',
        3: 'quinta',
        4: 'sexta',
        5: 'sabado',
        6: 'domingo',
    }
    today_str = day_mapping[date.today().weekday()]

    if activity.is_completed and not was_completed:
        # Verifica se todas as atividades do dia foram concluídas
        today_activities = WeeklyRoutineItem.objects.filter(
            user=request.user,
            day_of_week=today_str,
            is_completed=False
        ).exclude(pk=activity.pk) # Exclui a atividade atual para não contar ela mesma

        if not today_activities.exists():
            request.user.points += 5  # Adiciona 5 pontos por rotina diária completa
            request.user.save()
    elif not activity.is_completed and was_completed:
        # Se a atividade foi desmarcada, verifica se a rotina diária deixou de estar completa
        # Para isso, verificamos se ANTES de desmarcar esta atividade, todas as outras estavam completas
        # e AGORA, com esta desmarcada, não estão mais.
        all_activities_for_day_excluding_current = WeeklyRoutineItem.objects.filter(
            user=request.user,
            day_of_week=today_str
        ).exclude(pk=activity.pk)

        # Se antes de desmarcar, todas as atividades (incluindo a atual) estavam completas,
        # e agora, com a atual desmarcada, há alguma incompleta, significa que a rotina diária foi desfeita.
        # A forma mais simples de verificar isso é: se antes de desmarcar, o número de atividades completas
        # era igual ao total de atividades para o dia, e agora não é mais.
        
        # Contar atividades completas ANTES de desmarcar (considerando a 'activity' como completa)
        completed_before_unmark = WeeklyRoutineItem.objects.filter(
            user=request.user,
            day_of_week=today_str,
            is_completed=True
        ).count() + 1 # +1 para a atividade que está sendo desmarcada

        total_activities_for_day = WeeklyRoutineItem.objects.filter(
            user=request.user,
            day_of_week=today_str
        ).count()

        # Se a rotina diária estava completa e agora não está mais
        if completed_before_unmark == total_activities_for_day and not activity.is_completed:
            request.user.points -= 5  # Remove 5 pontos
            request.user.save()

    # Se for uma requisição AJAX, retorna JSON
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return JsonResponse({
            "success": True,
            "is_completed": activity.is_completed,
            "points": request.user.points
        })

    return redirect("weekly_routine")

