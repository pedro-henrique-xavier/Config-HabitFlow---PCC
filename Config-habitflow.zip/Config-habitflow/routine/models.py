from django.db import models
from django.conf import settings
from django.urls import reverse

DIAS_SEMANA = [
    ('segunda', 'Segunda'),
    ('terca', 'Terça'),
    ('quarta', 'Quarta'),
    ('quinta', 'Quinta'),
    ('sexta', 'Sexta'),
    ('sabado', 'Sábado'),
    ('domingo', 'Domingo'),
]

class WeeklyRoutineItem(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    day_of_week = models.CharField(max_length=10, choices=DIAS_SEMANA)
    title = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    time = models.TimeField()
    is_completed = models.BooleanField(default=False)  # ✅ NOVO

    class Meta:
        ordering = ['day_of_week', 'time']

    def __str__(self):
        return f"{self.time.strftime('%H:%M')} - {self.title}"

    def get_absolute_url(self):
        return reverse('weekly_routine')
