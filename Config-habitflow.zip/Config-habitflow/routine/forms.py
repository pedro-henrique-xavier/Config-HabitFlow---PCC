from django import forms
from .models import WeeklyRoutineItem

class WeeklyRoutineItemForm(forms.ModelForm):
    class Meta:
        model = WeeklyRoutineItem
        fields = ['title', 'description', 'time']
        widgets = {
            'time': forms.TimeInput(attrs={'type': 'time', 'class': 'form-control'}),
            'description': forms.Textarea(attrs={'rows': 2, 'class': 'form-control'}),
            'title': forms.TextInput(attrs={'class': 'form-control'}),
        }
